#' R implementation of dbo.fn_getT1NC_CatalSCRS
#'
#' @param species_codes TBD
#' @param stock_area_codes TBD
#' @param flag_names TBD
#' @param gear_group_codes TBD
#' @param num_years TBD
#' @param db_connection TBD
#' @return TBD
#' @export
catalogue.fn_getT1NC_fisheryRanks = function(species_codes = NULL, stock_area_codes = NULL, flag_names = NULL, gear_group_codes = NULL, num_years, db_connection = DB_STAT()) {
  # Rewritten as a pure SQL query
  SQL = "
    SELECT
    	'1-t1' AS DSet,
    	sp.Alfa3FAO AS Species,
    	t1.Year4 AS Year,
    	pt.StatusTypeID as Status,
    	fg.FlagName,
    	sta.SAreaName AS Stock,
    	gg.GearGrpCode AS GearGrp,
    	SUM(t1.CatchMT) AS Qty
    FROM
    	T1.dbo.T1CatchCur t1
    INNER JOIN
    	T1.dbo.InProcesses pr
    ON
    	pr.InProcID = t1.InProcID
    INNER JOIN
    	T1.dbo.Species sp
    ON
    	sp.SpeciesID = t1.SpeciesID
    INNER JOIN
    	T1.dbo.StatAreas sa
    ON
    	sa.AreaID = t1.AreaID
    INNER JOIN
    	T1.dbo.StocksStAreasDetails sad
    ON
    	sad.AreaID = sa.AreaID
    INNER JOIN
    	T1.dbo.StocksAreas sta
    ON
    	sta.StockAreaID = sad.StockAreaID AND
    	sp.StockBoundID = sta.StockBoundID
    INNER JOIN
    	T1.dbo.GearGrpBySpecies ggs
    ON
    	ggs.SpeciesID = sp.SpeciesID
    INNER JOIN
    	T1.dbo.GearGroups AS gg
    ON
    	ggs.GearGroupID = gg.GearGroupID
    INNER JOIN
    	T1.dbo.Gears AS gr
    ON
    	gg.GearGroupID = gr.GearGroupID AND
    	t1.GearID = gr.GearID
    INNER JOIN
    	T1.dbo.Fleets AS ft
    ON
    	t1.FleetID = ft.FleetID
    INNER JOIN
    	T1.dbo.Flags AS fg
    ON
    	ft.RepFlagID = fg.FlagID
    INNER JOIN
    	T1.dbo.Parties AS pt
    ON
    	pt.PartyID = fg.PartyID
    INNER JOIN
    	T1.dbo.CatchTypes dt
    ON
    	dt.CatchTypeID = t1.CatchTypeID
    WHERE
    	t1.CatchTypeID <> 22 AND -- Excluding live discards
    	t1.CatchMT > 0           -- Positive catches only
    GROUP BY
    	sp.Alfa3FAO,
    	pt.StatusTypeID,
    	fg.FlagName,
    	sta.SAreaName,
    	gg.GearGrpCode,
    	t1.Year4"

  start = Sys.time()
  DATA = tabular_query(db_connection, SQL)
  end   = Sys.time()

  if(!is.null(species_codes))    DATA = DATA[Species  %in% species_codes]
  if(!is.null(stock_area_codes)) DATA = DATA[Stock    %in% stock_area_codes]
  if(!is.null(flag_names))       DATA = DATA[FlagName %in% flag_names]
  if(!is.null(gear_group_codes)) DATA = DATA[GearGrp  %in% gear_group_codes]

  DEBUG(paste0("Fishery ranks execution time: ", end - start))

  last_year  = max(DATA$Year)
  first_year = last_year - num_years + 1

  DATA = DATA[Year >= first_year]

  DATA = DATA[, .(Qty = sum(Qty, na.rm = TRUE),
                  avgQty = sum(Qty, na.rm = TRUE) / ((last_year - first_year) + 1),
                  NumYears = length(unique(Year)),
                  YearMin = min(Year),
                  YearMax = max(Year)),
              keyby = .(Species, Status, FlagName, Stock, GearGrp)]

  DATA = DATA[, FisheryRank := frank(-avgQty, ties.method = "min")][order(FisheryRank)]

  DATA[, avgQtyRatio    := avgQty / sum(avgQty)]
  DATA[, avgQtyRatioCum := cumsum(avgQtyRatio)]

  return(
    DATA[, .(DSet = '1-t1',
             Species,
             Stock, Status, FlagName, GearGrp, Qty, avgQty, avgQtyRatio, avgQtyRatioCum, NumYears, YearMin, YearMax, FisheryRank)]
  )
}

#' R implementation of dbo.fn_getT1NC_CatalSCRS
#'
#' @param species_codes TBD
#' @param stock_area_codes TBD
#' @param year_from TBD
#' @param year_to TBD
#' @param db_connection TBD
#' @return TBD
catalogue.fn_genT1NC_CatalSCRS = function(species_codes = NULL, stock_area_codes = NULL, year_from = NA, year_to = NA, db_connection = DB_STAT()) {
  # Currently it just calls the DB function whose implementation is extremely complex due to the need of
  # mapping locations to stock areas (which could be improved through proper geospatial data mgmt.)

  Q_t1nc = paste(readLines(system.file("SQL/catT1NC.sql", package = "iccat.dev.data")), collapse = "\n")
  Q_t2ce = paste(readLines(system.file("SQL/catT2CE.sql", package = "iccat.dev.data")), collapse = "\n")
  Q_t2sz = paste(readLines(system.file("SQL/catT2SZ.sql", package = "iccat.dev.data")), collapse = "\n")

  if(!is.null(species_codes) & length(species_codes) > 0) {
    Q_t1nc = str_replace_all(Q_t1nc, "@SpeciesFilter", paste0("t1.Species IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ")"))
    Q_t2ce = str_replace_all(Q_t2ce, "@SpeciesFilter", paste0("ce.Species IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ")"))
    Q_t2sz = str_replace_all(Q_t2sz, "@SpeciesFilter", paste0("sz.Species IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ")"))
  } else {
    Q_t1nc = str_replace_all(Q_t1nc, "@SpeciesFilter", "1 = 1")
    Q_t2ce = str_replace_all(Q_t2ce, "@SpeciesFilter", "1 = 1")
    Q_t2sz = str_replace_all(Q_t2sz, "@SpeciesFilter", "1 = 1")
  }

  if(!is.null(stock_area_codes) & length(stock_area_codes) > 0) {
    Q_t1nc = str_replace_all(Q_t1nc, "@StocksFilter", paste0("t1.Stock IN (", paste0(shQuote(stock_area_codes, type = "sh"), collapse = ", "), ")"))
    Q_t2ce = str_replace_all(Q_t2ce, "@StocksFilter", paste0("ce.Stock IN (", paste0(shQuote(stock_area_codes, type = "sh"), collapse = ", "), ")"))
    Q_t2sz = str_replace_all(Q_t2sz, "@StocksFilter", paste0("sz.Stock IN (", paste0(shQuote(stock_area_codes, type = "sh"), collapse = ", "), ")"))
  } else {
    Q_t1nc = str_replace_all(Q_t1nc, "@StocksFilter", "1 = 1")
    Q_t2ce = str_replace_all(Q_t2ce, "@StocksFilter", "1 = 1")
    Q_t2sz = str_replace_all(Q_t2sz, "@StocksFilter", "1 = 1")
  }

  if(!is.na(year_from) | !is.na(year_to)) {
    if(is.na(year_from)) year_from = 0
    if(is.na(year_to))   year_to   = 9999

    Q_t1nc = str_replace_all(Q_t1nc, "@YearFilter", paste0("t1.YearC BETWEEN ", year_from, " AND ", year_to))
    Q_t2ce = str_replace_all(Q_t2ce, "@YearFilter", paste0("ce.YearC BETWEEN ", year_from, " AND ", year_to))
    Q_t2sz = str_replace_all(Q_t2sz, "@YearFilter", paste0("sz.YearC BETWEEN ", year_from, " AND ", year_to))
  } else {
    Q_t1nc = str_replace_all(Q_t1nc, "@YearFilter", "1 = 1")
    Q_t2ce = str_replace_all(Q_t2ce, "@YearFilter", "1 = 1")
    Q_t2sz = str_replace_all(Q_t2sz, "@YearFilter", "1 = 1")
  }

  DATA =
    tabular_query(
      db_connection,
      Q_t1nc
    )


  DATA = rbind(
    DATA,
    tabular_query(
      db_connection,
      Q_t2ce
    )
  )

  DATA = rbind(
    DATA,
    tabular_query(
      db_connection,
      Q_t2sz
    )
  )

  DEBUG(paste0("Data retrieval time: ", end - start))

  colnames(DATA)[which(colnames(DATA) == "DS")]        = "DSet"
  colnames(DATA)[which(colnames(DATA) == "YearC")]     = "Year"
  colnames(DATA)[which(colnames(DATA) == "StatusCPC")] = "Status"

  return(DATA)
}

#' TBD
#'
#' @param species_codes TBD
#' @param stock_area_codes TBD
#' @param last_n_years TBD
#' @param db_connection TBD
#' @return TBD
#' @export
catalogue = function(species_codes, stock_area_codes = NULL, last_n_years = 30, db_connection = DB_STAT()) {
  FR = catalogue.fn_getT1NC_fisheryRanks(species_codes    = species_codes,
                                         stock_area_codes = stock_area_codes,
                                         num_years        = last_n_years,
                                         db_connection    = db_connection)

  CA = catalogue.fn_genT1NC_CatalSCRS(species_codes    = species_codes,
                                      stock_area_codes = stock_area_codes,
                                      year_from        = min(FR$YearMin),
                                      year_to          = max(FR$YearMax),
                                      db_connection    = db_connection)

  return(catalogue.compile(FR, CA))
}

#' TBD
#'
#' @param table TBD
#' @param max_rows TBD
#' @return TBD
split_rows = function(table, max_rows = 60) {
  rows = data.table(min_row = integer(), max_row = integer())

  for(r in seq(1, nrow(catalogue), 60))
    rows = rbind(rows, data.table(min_row = r, max_row = min(r + max_rows - 1, nrow(table))))

  return(rows)
}

#' TBD
#'
#' @param catalogue TBD
#' @param max_rows TBD
#' @return TBD
#' @export
catalogue.split = function(catalogue, max_rows = 60) {
  rows = split_rows(catalogue, max_rows)

  return(apply(rows, 1, function(row) { catalogue[row[1]:row[2]] }))
}

#' TBD - temporarily export-ed
#'
#' @param fishery_ranks_data TBD
#' @param catalogue_data TBD
#' @return TBD
#' @export
catalogue.compile = function(fishery_ranks_data, catalogue_data) {
  if(is.null(fishery_ranks_data) || nrow(fishery_ranks_data) == 0) stop("No fishery ranks data available!")
  if(is.null(catalogue_data)     || nrow(catalogue_data) == 0)     stop("No catalogue data available!")

  FR = fishery_ranks_data
  CA = catalogue_data

  FR$DSet = NULL

  CA_NC = CA[DSet == "1-t1", .(Species, Year, Status, FlagName, Stock, GearGrp, QtyNC = Qty)]
  CA_CE = CA[DSet == "2-ce", .(QtyCE = sum(Qty, na.rm = TRUE)), keyby = .(Species, Year, Status, FlagName, Stock, GearGrp)]
  CA_SZ = CA[DSet == "3-sz", .(QtySZ = sum(Qty, na.rm = TRUE)), keyby = .(Species, Year, Status, FlagName, Stock, GearGrp)]
  CA_CS = CA[DSet == "4-cs", .(QtyCS = sum(Qty, na.rm = TRUE)), keyby = .(Species, Year, Status, FlagName, Stock, GearGrp)]

  CA_ALL = merge(CA_NC,  CA_CE, by = c("Species", "Year", "Status", "FlagName", "Stock", "GearGrp"), all.x = TRUE)
  CA_ALL = merge(CA_ALL, CA_SZ, by = c("Species", "Year", "Status", "FlagName", "Stock", "GearGrp"), all.x = TRUE)
  CA_ALL = merge(CA_ALL, CA_CS, by = c("Species", "Year", "Status", "FlagName", "Stock", "GearGrp"), all.x = TRUE)

  CA_ALL[, Score := ""]
  CA_ALL[!is.na(QtyCE), Score := paste0(Score, "a")]
  CA_ALL[!is.na(QtySZ), Score := paste0(Score, "b")]
  CA_ALL[!is.na(QtyCS), Score := paste0(Score, "c")]
  CA_ALL[Score == "", Score := "-1"]

  CA_final = CA_ALL[, .(Species, Stock, FlagName, Status, GearGrp, DSet = "t1", Year, Value = str_trim(format(round(QtyNC, 0), big.mark = ",")))]
  CA_final = rbind(CA_final, CA_ALL[, .(Species, Stock, FlagName, Status, GearGrp, DSet = "t2", Year, Value = Score)])

  start = Sys.time()

  CA_final_w = dcast.data.table(CA_final,
                                formula = Species + Stock + FlagName + Status + GearGrp + DSet ~ Year,
                                value.var = "Value",
                                drop = TRUE)

  end = Sys.time()

  log_debug(paste0("DCast-ing table (", nrow(CA_final), " -> ", nrow(CA_final_w), " rows): ", end - start))

  start = Sys.time()

  CA_W = merge(FR[, .(Species, Stock, FlagName, Status, GearGrp, FisheryRank,
                      TotCatches = round(Qty, 0), Perc = round(avgQtyRatio * 100, 2), PercCum = round(avgQtyRatioCum * 100, 2))], CA_final_w,
               by = c("Species", "Stock", "FlagName", "Status", "GearGrp"),
               all.x = TRUE, all.y = FALSE,
               sort = FALSE)

  end = Sys.time()

  DEBUG(paste0("Merging tables (", nrow(CA_W), " rows): ", end - start))

  return(CA_W)
}

#' TBD
#'
#' @param catalogue_data TBD
#' @param remove_species TBD
#' @param remove_stock TBD
#' @param truncate_years TBD
#' @return TBD
#' @export
catalogue.table = function(catalogue_data, show_catches_gradient = TRUE, remove_species = FALSE, remove_stock = FALSE, truncate_years = TRUE) {
  DEBUG("Building catalog table...")

  if(truncate_years) {
    column_names = colnames(catalogue_data)
    colnames(catalogue_data)[11:length(column_names)] = str_sub(colnames(catalogue_data)[11:length(column_names)], 3, 4)
  }

  catalogue_data[is.na(catalogue_data)] = "-"

  start = Sys.time()

  first_year_column = 11

  if(remove_species) {
    catalogue_data$Species = NULL
    first_year_column = first_year_column - 1
  }

  if(remove_stock) {
    catalogue_data$Stock = NULL
    first_year_column = first_year_column - 1
  }

  bg_matrix = catalogue_data[, first_year_column:ncol(catalogue_data)]

  bg_matrix =
    ifelse(is.na(bg_matrix) | bg_matrix == "-", "darkgrey",
           ifelse(bg_matrix == "-1", "red",
                  ifelse(bg_matrix == "a" | bg_matrix == "b" | bg_matrix == "c" | bg_matrix == "bc", "yellow",
                         ifelse(bg_matrix == "ab" | bg_matrix == "ac", "green",
                                ifelse(bg_matrix == "abc", "darkgreen",
                                       "white"
                                )
                         )
                  )
           )
    )

  fg_matrix = catalogue_data[, first_year_column:ncol(catalogue_data)]
  fg_matrix =
    ifelse(is.na(fg_matrix) | fg_matrix == "abc", "white", "black")

  #set_flextable_defaults(extra_css = "th p span, td p span { white-space: nowrap !important; }")

  FT = flextable(catalogue_data) %>%
    set_table_properties(opts_html = list(extra_css = "th p span, td p span { white-space: nowrap !important; }")) %>%
    #set_table_properties(layout = "autofit") %>%
    #add_header_row(top = TRUE, values = c("Party", "Fishery", "Catches", "", "Years"), colwidths = c(2, 2, 3, 1, ncol(catalogue_data) - first_year_column + 1)) %>%
    set_header_labels(values = list(FlagName = "Flag",
                                    GearGrp = "Gear",
                                    FisheryRank = "Rank",
                                    TotCatches = "Total (t)",
                                    Perc = "%",
                                    PercCum = "% (cum.)",
                                    DSet = "DS")) %>%

    #merge_v(part = "header", j = 8, combine = TRUE) %>%

    fontsize(size = 8, part = "all") %>%
    fontsize(size = 6, i = seq(1, nrow(catalogue_data), 2), j = first_year_column:ncol(catalogue_data), part = "body") %>%


    padding(padding        = 1, part = "all") %>%
    padding(padding.top    = 0, part = "body") %>%
    padding(padding.bottom = 0, part = "body") %>%
    padding(padding.left   = 5, part = "body", j = 3) %>%
    padding(padding.right  = 5, part = "body", j = 7:9) %>%

    flextable::bg   (part = "all",    bg = "white") %>%
    flextable::bg   (part = "header", bg = "gray") %>%

    flextable::bold(part = "header") %>%

    flextable::align(j = 1:ncol(catalogue_data), align = "center", part = "all")  %>%
    flextable::align(j = c("FlagName"),              align = "left",   part = "all")  %>%
    flextable::align(j = c("TotCatches",
                           "Perc",
                           "PercCum"),               align = "right",  part = "body") %>%

    flextable::align(j = first_year_column:ncol(catalogue_data),  align = "right",  part = "body") %>%

    flextable::valign(valign = "center", part = "all") %>%

    flextable::merge_v(c("FisheryRank",
                         "Species",
                         "Stock",
                         "FlagName",
                         "Status",
                         "GearGrp",
                         "TotCatches",
                         "Perc",
                         "PercCum"), part = "body", combine = TRUE) %>%

    flextable::border_inner(part = "all", border = fp_border(width = .5)) %>%
    flextable::border(part = "body", i = seq(2, nrow(catalogue_data), 2), border.bottom = fp_border(width = 1)) %>%

    flextable::color(part = "body", j = "GearGrp", i = catalogue_data[GearGrp == "UN", which = TRUE], color = "red") %>%

    flextable::bg   (part = "body", j = first_year_column:ncol(catalogue_data), bg    = bg_matrix)


  if(show_catches_gradient) {
    bg_matrix_catch = catalogue_data[, 8:9]
    #bg_matrix_catch$Perc    = rgb(.3, 1, .3, 1 - bg_matrix_catch$Perc    / 100)
    bg_matrix_catch$PercCum = rgb(.3, 1, .3,     bg_matrix_catch$PercCum / 100)

    FT = FT%>%
      #flextable::bg   (part = "body", j = 8, bg    = bg_matrix_catch$Perc) %>%
      flextable::bg   (part = "body", j = 9, bg    = bg_matrix_catch$PercCum)
  }

  FT = FT %>%

    flextable::color(part = "body", j = first_year_column:ncol(catalogue_data), color = fg_matrix) %>%

    flextable::width(j = first_year_column:ncol(catalogue_data), width = .30) %>%
    flextable::fix_border_issues() #%>%
    #flextable::autofit()

  end = Sys.time()

  DEBUG(paste0("Finished building catalog table in ", end - start))

  return(FT)
}
