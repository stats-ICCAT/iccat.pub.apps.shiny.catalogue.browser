#' TBD
#'
#' @param species_code TBD
#' @param species_family TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @return TBD
#' @export
t2sz_cs = function(species_codes = NULL, species_family = NULL, year_min = 1950,
                   db_connection = DB_STAT()) {

  Q_t2sz_cs = paste(readLines(system.file("SQL/outT2SZ+CS.sql", package = "iccat.dev.data")), collapse = "\n")

  Q_t2sz_cs =
    paste(Q_t2sz_cs, "
	WHERE
	  frq.FreqTypeCode <> 'AGEs' AND
	  szF.Nr > 0 AND
    szP.YearC >= ", year_min, " AND ",
          ifelse(!is.null(species_family),
                 paste0("sp.FamilyTx = '", species_family, "' AND "), ""),
          ifelse(!is.null(species_codes),
                 paste0("sp.SpeciesCode IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ") AND "), ""), "
    1 = 1
  GROUP BY
    szP.InProcID,
    pt.StatusTypeID,
    fg.FlagName,
    ft.FleetCode,
    szP.YearC,
   (szP.YearC / 10) * 10,
    sp.SpeciesCode,
    sp.SpeciesGrp,
    gg.GearGrpCode,
    gr.GearCode,
    szP.SizeInfoID,
    sloc.SampLocationCode,
    sch.SchoolTypeCode,
    frq.FreqTypeCode,
    szP.SzInterval,
    sl.SzClassLimitCode,
    flt.FileTypeCode,
    tp.TimePeriodGroup,
    st.SquareTypeCode,
    szS.Stock,
    si.SexCode;")

  return(
    tabular_query(
      db_connection,
      Q_t2sz_cs
    )
  )
}

#' TBD
#'
#' @param species_code TBD
#' @param species_family TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @param dataset_description TBD
#' @param out_folder TBD
#' @param out_filename_prefix TBD
#' @return TBD
#' @export
t2sz_cs.export = function(species_codes = NULL, species_family = NULL, year_min = 1950,
                          db_connection = DB_STAT(),
                          dataset_description = "T2SZ and T2CS detailed catalogue as reported in ST04-T2SZ and ST05-T2CS",
                          out_folder = ".", out_filename_prefix = "t2sz+cs-") {

  template = loadWorkbook(system.file("xlsx/t2sz+cs_template.xlsx", package = "iccat.dev.data"))

  T2SZ_CS = t2sz_cs(species_codes, species_family, year_min, db_connection)

  years = list(min = min(T2SZ_CS$YearC),
               max = max(T2SZ_CS$YearC))

  removeTable(wb = template, sheet = "Data", table = "Data")

  writeDataTable(wb = template, sheet = "Data",   T2SZ_CS,                                                           startRow = 1, startCol = 1, colNames = TRUE, tableStyle = "TableStyleLight11", tableName = "Data")
  writeData(     wb = template, sheet = "ReadMe", paste0(dataset_description, " (", years$min, "-", years$max, ")"), startRow = 1, startCol = 2)
  writeData(     wb = template, sheet = "ReadMe", as.character(Sys.Date()),                                          startRow = 2, startCol = 2)

  add_t2sz_cs_metadata(template, T2SZ_CS)

  activeSheet(template) = "Data"

  saveWorkbook(template, paste0(out_folder, "/", out_filename_prefix,
                                ifelse(is.null(species_codes), "ALL", paste0(species_codes, collapse = "+")),
                                ifelse(is.null(species_family), "", paste0("-", species_family)),
                                "_", str_replace_all(Sys.Date(), "-", ""), ".xlsx"), overwrite = TRUE)
}

add_t2sz_cs_metadata = function(template, T2SZ_CS_data) {
  year_start      = min(T2SZ_CS_data$YearC)
  year_end        = max(T2SZ_CS_data$YearC)
  years_tot       = year_end - year_start + 1
  years_data      = length(unique(T2SZ_CS_data[NrRecs > 0]$YearC))

  num_records     = nrow(T2SZ_CS_data)

  num_species     = length(unique(T2SZ_CS_data$SpeciesCode))
  num_fleets      = length(unique(T2SZ_CS_data$FleetCode))
  num_flags       = length(unique(T2SZ_CS_data$FlagName))
  num_gears       = length(unique(T2SZ_CS_data$GearCode))
  num_stocks      = length(unique(T2SZ_CS_data$Stock))
  num_time_strata = length(unique(T2SZ_CS_data$TimeStrata))
  num_geo_strata  = length(unique(T2SZ_CS_data$GeoStrata))
  num_freq_types  = length(unique(T2SZ_CS_data$FreqTypeCode))

  num_samples     = round(sum(T2SZ_CS_data$NrRecs, na.rm = TRUE), 0)
  num_fish        = round(sum(T2SZ_CS_data$NrFish, na.rm = TRUE), 0)

  writeData(wb = template, sheet = "ReadMe", year_start,      startRow =  5, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", year_end,        startRow =  6, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_tot,       startRow =  7, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_data,      startRow =  8, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_records,     startRow =  9, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_species,     startRow = 10, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_fleets,      startRow = 11, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_flags,       startRow = 12, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_gears,       startRow = 13, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_stocks,      startRow = 14, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_time_strata, startRow = 15, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_geo_strata,  startRow = 16, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_freq_types,  startRow = 17, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_samples,     startRow = 18, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_fish,        startRow = 19, startCol = 2)
}
