# See: https://stackoverflow.com/questions/23252231/r-data-table-breaks-in-exported-functions
.datatable.aware = TRUE

#' TBD
#'
#' @param species_codes TBD
#' @param exclude_zero_catches TBD
#' @param exclude_discarded_live TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @return TBD
#' @export
t1nc = function(species_codes, exclude_zero_catches = FALSE, exclude_discarded_live = TRUE, year_min = 1950,
                db_connection = DB_T1()) {
  Q_t1nc = paste(readLines(system.file("SQL/outT1NC.sql", package = "iccat.dev.data")), collapse = "\n")

  Q_t1nc =
    paste(Q_t1nc, "
  	WHERE
      t1.Year4 >= ", year_min, " AND
      t1.CatchMT ", ifelse(exclude_zero_catches, ">", ">="), " 0 AND
      t1.CatchTypeID ", ifelse(exclude_discarded_live, "<>", "="), " 22 AND
      sp.Alfa3FAO IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ")
  	ORDER BY
    	t1.RecID,
    	t1.Year4,
    	sp.SpeciesGrp,
    	sp.Alfa3FAO,
    	pa.StatusTypeID,
    	fg.FlagName,
    	ft.FleetCode,
    	sta.SAreaName,
    	sa.AreaCode,
    	fz.CatchCodeDescrip,
    	gr.GearCode,
    	dt.CatchTypeCode,
    	qi.QualInfoCode,
    	qi.QInfoGroup
    ")

  return(
    tabular_query(
      db_connection,
      Q_t1nc
    )
  )
}

#' TBD
#'
#' @param species_codes TBD
#' @param exclude_zero_catches TBD
#' @param exclude_discarded_live TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @param dataset_description TBD
#' @param out_folder TBD
#' @param out_filename_prefix TBD
#' @return TBD
#' @export
t1nc.export = function(species_codes, exclude_zero_catches = FALSE, exclude_discarded_live = TRUE, year_min = 1950,
                       db_connection = DB_T1(), dataset_description = "T1NC", out_folder = ".", out_filename_prefix = "t1nc-") {

  template = loadWorkbook(system.file("xlsx/t1nc_template.xlsx", package = "iccat.dev.data"))

  T1NC = t1nc(species_codes, exclude_zero_catches, exclude_discarded_live, year_min, db_connection)

  add_t1nc_metadata(template, T1NC)

  years = list(min = min(T1NC$YearC),
               max = max(T1NC$YearC))

  record_description = paste0("catches ", ifelse(exclude_zero_catches, ">", ">="), " 0")
  record_description = paste0(record_description, ", ", ifelse(exclude_discarded_live, "excluding live discards", "live discards only"))

  removeTable(wb = template, sheet = "Data", table = "Data")

  writeDataTable(wb = template, sheet = "Data",   T1NC,                                                                                         startRow = 1, startCol = 1, colNames = TRUE, tableStyle = "TableStyleLight11", tableName = "Data")
  writeData(     wb = template, sheet = "ReadMe", paste0(dataset_description, " (", years$min, "-", years$max, ") [", record_description, "]"), startRow = 1, startCol = 2)
  writeData(     wb = template, sheet = "ReadMe", as.character(Sys.Date()),                                                                     startRow = 2, startCol = 2)

  activeSheet(template) = "Data"

  saveWorkbook(template, paste0(out_folder, "/", out_filename_prefix,
                                ifelse(is.null(species_codes), "ALL", paste0(species_codes, collapse = "+")),
                                "_", str_replace_all(Sys.Date(), "-", ""), ".xlsx"), overwrite = TRUE)
}

add_t1nc_metadata = function(template, T1NC_data) {
  year_start         = min(T1NC_data$YearC)
  year_end           = max(T1NC_data$YearC)
  years_tot          = year_end - year_start + 1
  years_data         = length(unique(T1NC_data[Qty_t > 0]$YearC))

  num_records        = nrow(T1NC_data)

  num_species        = length(unique(T1NC_data$Species))
  num_fleets         = length(unique(T1NC_data$FleetCode))
  num_flags          = length(unique(T1NC_data$FlagName))
  num_parties        = length(unique(T1NC_data$PartyName))
  num_gears          = length(unique(T1NC_data$GearCode))
  num_stocks         = length(unique(T1NC_data$Stock))
  num_sample_areas   = length(unique(T1NC_data$SampAreaCode))
  num_areas          = length(unique(T1NC_data$Area))
  num_catch_types    = length(unique(T1NC_data$CatchTypeCode))

  tot_catches        = round(sum(T1NC_data$Qty_t, na.rm = TRUE), 2)
  avg_catches        = tot_catches / length(unique(T1NC_data$YearC))
  est_catches        = round(sum(T1NC_data[CatchSource == "Estimated"]$Qty_t, na.rm = TRUE), 2)

  avg_est_catches    = est_catches / length(unique(T1NC_data$YearC))

  data_30 = T1NC_data[YearC %in% (year_end - 29):year_end]

  tot_catches_30     = round(sum(data_30$Qty_t), 2)
  avg_catches_30     = round(tot_catches_30 / 30, 2)
  est_catches_30     = round(sum(data_30[CatchSource == "Estimated"]$Qty_t, na.rm = TRUE), 2)
  avg_est_catches_30 = round(est_catches_30 / 30, 2)

  writeData(wb = template, sheet = "ReadMe", year_start,         startRow =  5, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", year_end,           startRow =  6, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_tot,          startRow =  7, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_data,         startRow =  8, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_records,        startRow =  9, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_species,        startRow = 10, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_fleets,         startRow = 11, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_flags,          startRow = 12, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_parties,        startRow = 13, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_gears,          startRow = 14, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_stocks,         startRow = 15, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_sample_areas,   startRow = 16, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_areas,          startRow = 17, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_catch_types,    startRow = 18, startCol = 2)

  writeData(wb = template, sheet = "ReadMe", tot_catches,        startRow = 19, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", avg_catches,        startRow = 20, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", est_catches,        startRow = 21, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", avg_est_catches,    startRow = 22, startCol = 2)

  writeData(wb = template, sheet = "ReadMe", tot_catches_30,     startRow = 23, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", avg_catches_30,     startRow = 24, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", est_catches_30,     startRow = 25, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", avg_est_catches_30, startRow = 26, startCol = 2)
}
