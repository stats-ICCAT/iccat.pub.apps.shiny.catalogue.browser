#' TBD
#'
#' @param species_code TBD
#' @param species_family TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @return TBD
#' @export
t2ce = function(species_codes = NULL, species_family = NULL, year_min = 1950,
                db_connection = DB_STAT()) {
  Q_t2ce = paste(readLines(system.file("SQL/outT2CE.sql", package = "iccat.dev.data")), collapse = "\n")

  Q_t2ce =
    paste(Q_t2ce, "
	WHERE
	  ceE.PriorityID = 1 AND
	  ceC.CatchStdCE > 0 AND
    ceP.YearC >= ", year_min, " AND ",
          ifelse(!is.null(species_family),
                 paste0("sp.FamilyTx = '", species_family, "' AND "), ""),
          ifelse(!is.null(species_codes),
                 paste0("sp.SpeciesCode IN (", paste0(shQuote(species_codes, type = "sh"), collapse = ", "), ") AND "), ""), "
    1 = 1
  GROUP BY
  	ceP.InProcID,
  	ceP.YearC,
  	ceP.YearC,FLOOR(ceP.YearC / 10) * 10,
  	gg.GearGrpCode,
  	gr.GearCode,
  	ceP.CovRatio,
  	pt.StatusTypeID,
  	fg.FlagName,
  	ft.FleetCode,
  	ftt.FileTypeCode,
  	et.EffortTypeCode,
  	fm.SchoolTypeCode,
  	ct.CatchTypeCode,
  	ptt.ProductTypeCode,
  	tp.TimePeriodGroup,
  	st.SquareType,
  	sp.SpeciesGrp,
  	sp.SpeciesCode,
  	dbo.fn_getSpeciesStockFromLatLon(sp.SpeciesCode, ceS.QuadID, ceS.Lat, ceS.Lon)
  ORDER BY
  	ceP.YearC,
  	pt.StatusTypeID,
  	fg.FlagName,
  	ft.FleetCode,
  	gr.GearCode,
  	ftt.FileTypeCode,
  	et.EffortTypeCode,
  	ct.CatchTypeCode,
  	ptt.ProductTypeCode,
  	tp.TimePeriodGroup,
  	st.SquareType,
  	sp.SpeciesGrp,
  	sp.SpeciesCode")

  return(
    tabular_query(
      db_connection,
      Q_t2ce
    )
  )
}

#' TBD
#'
#' @param species_code TBD
#' @param species_family TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @param dataset_description TBD
#' @param out_folder TBD
#' @param out_filename_prefix TBD
#' @return TBD
#' @export
t2ce.export = function(species_codes = NULL, species_family = NULL, year_min = 1950,
                       db_connection = DB_STAT(), dataset_description = "T2CE", out_folder = ".", out_filename_prefix = "t2ce-") {

  template = loadWorkbook(system.file("xlsx/t2ce_template.xlsx", package = "iccat.dev.data"))

  T2CE = t2ce(species_codes, species_family, year_min, db_connection)


  years = list(min = min(T2CE$YearC),
               max = max(T2CE$YearC))

  removeTable(wb = template, sheet = "Data", table = "Data")

  writeDataTable(wb = template, sheet = "Data",   T2CE,                                                              startRow = 1, startCol = 1, colNames = TRUE, tableStyle = "TableStyleLight11", tableName = "Data")
  writeData(     wb = template, sheet = "ReadMe", paste0(dataset_description, " (", years$min, "-", years$max, ")"), startRow = 1, startCol = 2)
  writeData(     wb = template, sheet = "ReadMe", as.character(Sys.Date()),                                          startRow = 2, startCol = 2)

  add_t2ce_metadata(template, T2CE)

  activeSheet(template) = "Data"

  saveWorkbook(template, paste0(out_folder, "/", out_filename_prefix,
                                ifelse(is.null(species_codes), "ALL", paste0(species_codes, collapse = "+")),
                                ifelse(is.null(species_family), "", paste0("-", species_family)),
                                "_", str_replace_all(Sys.Date(), "-", ""), ".xlsx"), overwrite = TRUE)
}

add_t2ce_metadata = function(template, T2CE_data) {
  year_start       = min(T2CE_data$YearC)
  year_end         = max(T2CE_data$YearC)
  years_tot        = year_end - year_start + 1
  years_data       = length(unique(T2CE_data[qty > 0]$YearC))

  num_records      = nrow(T2CE_data)

  num_species      = length(unique(T2CE_data$SpeciesCode))
  num_fleets       = length(unique(T2CE_data$FleetCode))
  num_flags        = length(unique(T2CE_data$FlagName))
  #num_parties      = length(unique(T2CE_data$PartyName))
  num_gears        = length(unique(T2CE_data$GearCode))
  num_time_strata  = length(unique(T2CE_data$TimeStrata))
  num_geo_strata   = length(unique(T2CE_data$GeoStrata))
  num_effort_types = length(unique(T2CE_data$EffortUnit))
  num_catch_types  = length(unique(T2CE_data$CatchTypeCode))

  writeData(wb = template, sheet = "ReadMe", year_start,      startRow =  5, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", year_end,        startRow =  6, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_tot,       startRow =  7, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", years_data,      startRow =  8, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_records,     startRow =  9, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_species,     startRow = 10, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_fleets,      startRow = 11, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_flags,       startRow = 12, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_gears,       startRow = 13, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_time_strata, startRow = 14, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_geo_strata,  startRow = 15, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_effort_types,startRow = 16, startCol = 2)
  writeData(wb = template, sheet = "ReadMe", num_catch_types, startRow = 17, startCol = 2)
}
