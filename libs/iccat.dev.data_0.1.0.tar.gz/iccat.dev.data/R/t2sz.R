#' TBD
#'
#' @param species_codes TBD
#' @param year_min TBD
#' @param year_max TBD
#' @param type_of_records TBD
#' @param db_connection TBD
#' @return TBD
#' @export
t2sz = function(species_codes = NULL, year_min = 1950, year_max = NA, type_of_records = T2SZ_SIZE,
                db_connection = DB_STAT()) {
  Q_t2sz = paste(readLines(system.file("SQL/outT2SZ.sql", package = "iccat.dev.data")), collapse = "\n")

  Q_t2sz = str_replace_all(Q_t2sz, "@SpeciesCodes",  paste0(shQuote(species_codes, type = "sh"), collapse = ", "))
  Q_t2sz = str_replace_all(Q_t2sz, "@YearMin",       as.character(year_min))
  Q_t2sz = str_replace_all(Q_t2sz, "@YearMax",       as.character(ifelse(is.na(year_max), format(Sys.Date(), "%Y"), year_max)))
  Q_t2sz = str_replace_all(Q_t2sz, "@TypeOfRecords", paste0("'", type_of_records, "'"))

  return(
    tabular_query(
      db_connection,
      Q_t2sz
    )
  )
}

#' TBD
#'
#' @param species_codes TBD
#' @param year_min TBD
#' @param year_max TBD
#' @param type_of_records TBD
#' @param db_connection TBD
#' @param out_folder TBD
#' @param out_filename_prefix TBD
#' @param gzip TBD
#' @return TBD
#' @export
t2sz.export = function(species_codes, year_min = 1950, year_max = NA, type_of_records = T2SZ_SIZE,
                       db_connection = DB_STAT(), out_folder = ".", out_filename_prefix = "t2sz-", gzip = TRUE) {

  T2SZ = t2sz(species_codes, year_min, year_max, type_of_records, db_connection)

  fwrite(T2SZ, file = paste0(out_folder, "/", out_filename_prefix, type_of_records, "-",
                             ifelse(is.null(species_codes), "ALL", paste0(species_codes, collapse = "+")),
                             "_", str_replace_all(Sys.Date(), "-", ""),
                             paste0(".csv", ifelse(gzip, ".gz", ""))))
}
