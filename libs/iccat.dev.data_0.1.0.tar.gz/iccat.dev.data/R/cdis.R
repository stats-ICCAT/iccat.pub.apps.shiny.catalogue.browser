#' TBD
#'
#' @param species_codes TBD
#' @param exclude_zero_catches TBD
#' @param exclude_discarded_live TBD
#' @param year_min TBD
#' @param db_connection TBD
#' @return TBD
#' @export
catdis = function(species_codes, year_min = 1950, year_max = NA,
                  db_connection = DB_CATDIS()) {
  Q_catdis = paste(readLines(system.file("SQL/catdis.sql", package = "iccat.dev.data")), collapse = "\n")

  Q_catdis = str_replace_all(Q_catdis, "@SpeciesCode", paste0(shQuote(species_codes, type = "sh"), collapse = ", "))
  Q_catdis = str_replace_all(Q_catdis, "@YearMin", as.character(year_min))
  Q_catdis = str_replace_all(Q_catdis, "@YearMax", as.character(ifelse(is.na(year_max), 9999, year_max)))

  catdis =
    tabular_query(
      db_connection,
      Q_catdis
    )

  catdis_out = catdis
  catdis_out[GearGrp == "oth", GearGrp := "OT"]
  catdis_out$Catch_t = NULL

  catdis_out[, yLat5ctoid := ifelse(QuadID %in% c(1, 4), 1, -1) * (Lat5 + 2.5)]
  catdis_out[, xLon5ctoid := ifelse(QuadID %in% c(1, 2), 1, -1) * (Lon5 + 2.5)]

  catdis_out[, CWPCode    := paste0("6",
                                    QuadID,
                                    str_sub(paste0("0" , Lat5), -2),
                                    str_sub(paste0("00", Lon5), -3))]

  catdis_out[, pID        := paste0(str_sub(paste0("00", Lon5), -3), ifelse(QuadID %in% c(1, 4), "N", "S"),
                                    str_sub(paste0("0" , Lat5), -2), ifelse(QuadID %in% c(1, 2), "E", "W"))]

  catdis_out$Catch_t    = catdis$Catch_t

  all_gears = sort(unique(catdis_out$GearGrp))

  has_others = length(which(all_gears == "OT")) > 0

  gears = all_gears[which(all_gears != "OT")]

  if(has_others) gears = append(gears, "OT")

  catdis_out$GearGrp =
    factor(
      catdis_out$GearGrp,
      levels = REF_GEAR_GROUPS[CODE %in% gears]$CODE,
      labels = REF_GEAR_GROUPS[CODE %in% gears]$CODE,
      ordered = TRUE
    )

  return(
    catdis_out
  )
}

#' TBD
#'
#' @param species_codes TBD
#' @param year_min TBD
#' @param year_max TBD
#' @param db_connection TBD
#' @param out_folder TBD
#' @param out_filename_prefix TBD
#' @param gzipped TBD
#' @return TBD
#' @export
catdis.export = function(species_codes, year_min = 1950, year_max = NA,
                         db_connection = DB_CATDIS(),
                         out_folder = ".", out_filename_prefix = "cdis-", gzipped = TRUE) {

  catdis = catdis(species_codes, year_min, year_max, db_connection)

  years = list(min = min(catdis$YearC),
               max = max(catdis$YearC))

  fwrite(catdis, file = paste0(out_folder, "/",
                               out_filename_prefix, paste0(species_codes, collapse = "_"),
                               str_sub(as.character(years$min), -2), str_sub(as.character(years$max), -2),
                               paste0(".csv", ifelse(gzipped, ".gz", ""))))
}

