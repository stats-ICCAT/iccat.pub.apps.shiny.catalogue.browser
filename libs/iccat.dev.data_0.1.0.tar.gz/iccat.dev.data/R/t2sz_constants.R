#' The constant to select (raw) size data from t2sz
#' @export
T2SZ_SIZE = "siz"

#' The constant to select catch-at-size data from t2sz
#' @export
T2SZ_CAS  = "cas"
