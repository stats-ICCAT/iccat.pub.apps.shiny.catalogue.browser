-- T2SZ CATALOGUE
SELECT
	DS,
	Species,
	YearC,
	StatusCPC,
	FlagName,
	Stock,
	Stock2,
	GearGrp,
	Qty,
	QtyUnit,
	TimeStrata,
	GeoStrata,
	ClassInterval,
	FreqTypeCode
FROM (
	SELECT
		sz.DS,
		sz.Species,
		sz.YearC,
		sz.StatusCPC,
		sz.FlagName,
		sz.Stock,
		sz.Stock AS Stock2,
		sz.GearGrp,
		SUM(sz.Nr) AS Qty,
		sz.QtyUnit,
		sz.TimeStrata,
		sz.GeoStrata,
		ClassInterval = STR(sz.SzInterval, 2, 0) + sz.QtyUnit + '(' + sz.szLimit + ')',
		FreqTypeCode
	FROM (
		SELECT
			CASE
				WHEN szP.SizeInfoID IN (0, 4) THEN '3-sz'
				WHEN szP.SizeInfoID = 1 THEN '4-cs'
				ELSE '??'
			END AS DS,
			sp.SpeciesCode AS Species,
			szP.YearC,
			pt.StatusTypeID AS StatusCPC,
			fg.FlagName,
			CASE
				WHEN szS.Stock = 'ATL' AND sp.SpeciesCode IN ('BLT', 'BRS', 'CER', 'DOL', 'KGM', 'KGX', 'MAW', 'SLT', 'SSM', 'WAH', 'COM')
				THEN 'A+M'
				ELSE szS.Stock
			END AS Stock,
			gg.GearGrpCode AS GearGrp,
			szF.Nr,
			ts.TimePeriodGroup AS TimeStrata,
			gs.SquareTypeCode AS GeoStrata,
			CASE
				WHEN fr.GroupID = 'L' THEN 'cm'
				WHEN fr.GroupID = 'W' THEN 'kg'
				WHEN fr.GroupID = 'A' THEN 'yr'
				ELSE '?'
			END AS QtyUnit,
			szP.SzInterval,
			LOWER(sl.SzClassLimitCode) AS szLimit,
			fr.FreqTypeCode,
			si.SizeInfoCode
		FROM
			dbSTAT.dbo.t2szProcesses szP
		INNER JOIN
			dbSTAT.dbo.t2szStrata szS
		ON
			szP.InProcID = szS.InProcID
		INNER JOIN
			dbSTAT.dbo.t2szFreqs AS szF
		ON
			szF.StrataID = szS.StrataID
		INNER JOIN
			dbSTAT.dbo.Fleets ft
		ON
			szP.FleetID = ft.FleetID
		INNER JOIN
			dbSTAT.dbo.Flags fg
		ON
			fg.FlagID = ft.RepFlagID
		INNER JOIN
			dbSTAT.dbo.Parties pt
		ON
			pt.PartyID = fg.PartyID
		INNER JOIN
			dbSTAT.dbo.Species sp
		ON
			szP.SpeciesID = sp.SpeciesID
		INNER JOIN
			dbSTAT.dbo.Gears gr
		ON
			szP.GearID = gr.GearID
		INNER JOIN
			dbSTAT.dbo.GearGroups gg
		ON
			gg.GearGrpID = gr.GearGrpID
		INNER JOIN
			dbSTAT.dbo.SquareTypes gs
		ON
			gs.SquareTypeID = szS.SquareTypeID
		INNER JOIN
			dbSTAT.dbo.TimePeriods ts
		ON
			ts.TimePeriodID = szS.TimePeriodCatch
		INNER JOIN
			dbSTAT.dbo.SizeClassLimits sl
		ON
			sl.SzClassLimitID = szP.SzClassLimit
		INNER JOIN
			dbSTAT.dbo.FreqTypes fr
		ON
			fr.FreqTypeID = szP.FreqTypeID
		INNER JOIN
			dbSTAT.dbo.SizeInfo si
		ON
			si.SizeInfoID = szP.SizeInfoID
		WHERE
			sp.SpeciesCode IN (
				'ALB', 'BFT', 'YFT', 'BET', 'SKJ', 'SWO', 'BUM', 'WHM', 'SAI', 'SPF',
				'BSH', 'POR', 'SMA',
				'BON','LTA','BOP', 'FRI', 'BLF', 'BLT', 'BRS', 'CER', 'DOL', 'KGM', 'KGX', 'MAW', 'SLT', 'SSM', 'WAH', 'COM'
			) AND
			ts.TimePeriodGroup IN ('mm', 'qq') AND
			gs.SquareTypeCode IN ('1x1', '5x5', '5x10', '10x10', 'LatLon', '10x20', 'ICCAT')
	) AS sz
	WHERE
		@SpeciesFilter AND
    @StocksFilter AND
    @YearFilter
	GROUP BY
		sz.DS,
		sz.Species,
		sz.YearC,
		sz.StatusCPC,
		sz.FlagName,
		sz.Stock,
		sz.GearGrp,
		sz.QtyUnit,
		sz.TimeStrata,
		sz.GeoStrata,
		sz.SzInterval,
		sz.szLimit,
		FreqTypeCode
) sz2
