WITH T1 AS (
	SELECT
		szP.InProcID,
		sp.SpeciesCode,
		szP.YearC,
		fg.FlagName,
		ft.FleetCode,
		gg.GearGrpCode,
		gr.GearCode,
		frqt.FreqTypeCode,
		szP.SzInterval,
		CASE
			WHEN szP.GearID IN (33, 35, 37, 38, 39, 40, 80, 81, 82, 83, 84) THEN 'DD'
			ELSE 'L'
		END AS LorD,
		CASE
			WHEN frqt.FreqTypeCode IN ('WGT','HGTW') THEN 'kg (' + lower(cl.SzClassLimitCode) + ')'
			ELSE 'cm (' + lower(cl.SzClassLimitCode) + ')'
		END AS FreqsGroup,
		si.SizeInfoCode,
		filet.FileTypeCode
	FROM
		dbo.t2szProcesses szP
	INNER JOIN
		dbo.Species sp
	ON
		sp.SpeciesID = szP.SpeciesID
	INNER JOIN
		dbo.Fleets ft
	ON
		ft.FleetID = szP.FleetID
	INNER JOIN
		dbo.Flags fg
	ON
		fg.FlagID = ft.RepFlagID
	INNER JOIN
		dbo.Gears gr
	ON
		gr.GearID = szP.GearID
	INNER JOIN
		dbo.GearGroups gg
	ON
		gg.GearGrpID = gr.GearGrpID
	INNER JOIN
		dbo.FreqTypes frqt
	ON
		frqt.FreqTypeID = szP.FreqTypeID
	INNER JOIN
		dbo.SizeClassLimits cl
	ON
		cl.SzClassLimitID = szP.SzClassLimit
	INNER JOIN
		dbo.SizeInfo si
	ON
		si.SizeInfoID = szP.SizeInfoID
	INNER JOIN
		dbo.FileTypes filet
	ON
		filet.FileTypeID = szP.FileTypeID
	WHERE
		sp.SpeciesCode IN (@SpeciesCodes) AND
		YearC BETWEEN @YearMin AND @YearMax AND
		szP.FileTypeID NOT IN (0, 3, 4, 5, 7, 12, 13, 14, 15, 21, 23, 50) AND
		si.SizeInfoCode = @TypeOfRecords -- 'siz' for actual size-frequency, 'cas' for catch-at-size, etc. (see [dbSTAT].[dbo].[SizeInfo])
), T2 AS (
SELECT
	szS.StrataID,
	szS.InProcID,
	szS.TimePeriodCatch,
	tp.TimePeriodGroup AS TimeStrata,
	st.SchoolTypeCode,
	szS.Stock,
	sa.SampAreaCode,
	sqt.SquareTypeCode AS GeoStrata,
	QuadID,
	Lat,
	Lon,
	CatchWGT,
	CatchNUM,
	NrSamples,
	FishSampWGT,
	FishSampNUM
FROM
	t2szStrata szS
INNER JOIN
	TimePeriods tp
ON
	tp.TimePeriodID = szS.TimePeriodCatch
INNER JOIN
	SchoolTypes st
ON
	st.SchoolTypeID = szS.SchoolTypeID
INNER JOIN
	SamplingAreas sa
ON
	sa.SampAreaID = szS.SampAreaID
INNER JOIN
	SquareTypes sqt
ON
	sqt.SquareTypeID = szS.SquareTypeID
WHERE
	szS.InProcID IN (SELECT DISTINCT InProcID FROM T1)
), T3 AS (
SELECT
	szF.StrataID,
	szF.SizeClass AS ClassFrq,
	sx.SexCode,
	sum(szF.Nr) AS Nr
FROM
	t2szFreqs szF
INNER JOIN
	SexInfo sx
ON
	sx.SexID = szF.SexID
WHERE
	StrataID IN (SELECT DISTINCT StrataID FROM T2)
GROUP BY
	szF.StrataID,
	szF.SizeClass,
	sx.SexCode
)

SELECT
	szP.InProcID,
	szP.SpeciesCode,
	szP.YearC,
	FLOOR(szP.YearC / 10) * 10 AS Decade,
	szP.FlagName,
	szP.FleetCode,
	szP.GearGrpCode,
	szP.GearCode,
	szP.LorD,
	szP.FreqTypeCode,
	szP.SzInterval,
	szP.FreqsGroup,
	szP.SizeInfoCode,
	szP.FileTypeCode,
	szS.StrataID,
	szS.TimePeriodCatch,
	szS.TimeStrata,
	szS.SchoolTypeCode,
	szS.Stock,
	szS.SampAreaCode,
	szS.GeoStrata,
	szS.QuadID,
	FLOOR(szS.Lat) AS Lat, FLOOR(szS.Lon) AS Lon,
	szS.FishSampWGT,
	szS.FishSampNUM,
	szF.ClassFrq,
	szF.SexCode,
	ROUND(SUM(szF.Nr), 0) AS Nr
FROM
	T1 szP
INNER JOIN
	T2 szS
ON
	szP.InProcID = szS.InProcID
INNER JOIN
	T3 szF
ON
	szS.StrataID = szF.StrataID
INNER JOIN
	Species sp
ON
	sp.SpeciesCode = szP.SpeciesCode
WHERE
	szP.SizeInfoCode = @TypeOfRecords -- 'siz' for actual size-frequency, 'cas' for catch-at-size, etc. (see [dbSTAT].[dbo].[SizeInfo])
GROUP BY
	szP.InProcID,
	szP.SpeciesCode,
	szP.YearC,
	FLOOR(szP.YearC / 10) * 10,
	szP.FlagName,
	szP.FleetCode,
	szP.GearGrpCode,
	szP.GearCode,
	szP.LorD,
	szP.FreqTypeCode,
	szP.SzInterval,
	szP.FreqsGroup,
	szP.SizeInfoCode,
	szP.FileTypeCode,
	szS.StrataID,
	szS.TimePeriodCatch,
	szS.TimeStrata,
	szS.SchoolTypeCode,
	szS.Stock,
	szS.SampAreaCode,
	szS.GeoStrata,
	szS.QuadID,
	szS.Lat,
	szS.Lon,
	szS.FishSampWGT,
	szS.FishSampNUM,
	szF.ClassFrq,
	szF.SexCode
HAVING
	SUM(szF.Nr) > 0
ORDER BY
	szP.InProcID,
	szP.YearC,
	szP.FleetCode,
	szP.GearGrpCode,
	szP.GearCode,
	szP.FreqTypeCode,
	szP.SzInterval,
	szP.FreqsGroup,
	szP.SizeInfoCode,
	FileTypeCode,
	szS.TimeStrata,
	szS.TimePeriodCatch,
	szS.SampAreaCode,
	szS.GeoStrata,
	szF.ClassFrq
;
