SELECT 
	t1.RecID,
	sp.Alfa3FAO as Species,
	sp.ScieName,
	sp.SpeciesGrp,
	t1.Year4 AS YearC,
	FLOOR(t1.Year4 / 10) * 10 AS Decade,
	FLOOR(t1.Year4 / 5) * 5 AS Lustrum,
	pa.StatusTypeID AS PartyStatus,
	pa.PartyName,
	fg.FlagName,
	ft.FleetCode,
	sta.SAreaName AS Stock,
	spa.SampAreaCode,
	sa.AreaCode AS Area,
	ggs.SpGearGroup AS SpcGearGrp,
	gg.GearGrpCode AS GearGrp,
	gr.GearCode,
	dt.CatchTypeCode,
	fz.CatchCodeDescrip as FishZoneCode,
	qi.QualInfoCode,
	--qi.QInfoGroup,
	t1.CnvFactor,
	t1.CatchMT AS Qty_t,
	CASE
		WHEN qi.QualInfoCode IN ('UNKN', 'RPT1', 'RNAT', 'RPT2', 'RSCR') THEN 'Reported'
		ELSE 'Estimated'
	END as CatchSource
	--pr.DateRef, 
	--pr.InProcID, 
	--pr.DocRef
FROM 
	dbo.T1CatchCur t1 
INNER JOIN 
	dbo.Species sp 
ON 
	t1.SpeciesID = sp.SpeciesID 
INNER JOIN 
	dbo.GearGrpBySpecies ggs 
ON 
	ggs.SpeciesID = sp.SpeciesID 
INNER JOIN 
	dbo.GearGroups gg 
ON 
	ggs.GearGroupID = gg.GearGroupID 
INNER JOIN 
	dbo.Gears gr 
ON 
	gg.GearGroupID = gr.GearGroupID AND 
	t1.GearID = gr.GearID 
INNER JOIN 
	dbo.StatAreas sa 
ON 
	t1.AreaID = sa.AreaID 
INNER JOIN 
	dbo.StocksStAreasDetails sad 
ON 
	sa.AreaID = sad.AreaID 
INNER JOIN 
	dbo.StocksAreas sta 
ON 
	sad.StockAreaID = sta.StockAreaID AND sp.StockBoundID = sta.StockBoundID 
INNER JOIN 
	dbo.CatchTypes dt 
ON 
	t1.CatchTypeID = dt.CatchTypeID 
INNER JOIN 
	dbo.Fleets ft 
ON 
	t1.FleetID = ft.FleetID 
INNER JOIN 
	dbo.Flags fg 
ON 
	ft.RepFlagID = fg.FlagID 
INNER JOIN 
	dbo.Parties pa 
ON 
	fg.PartyID = pa.PartyID 
INNER JOIN 
	dbo.InProcesses pr 
ON 
	t1.InProcID = pr.InProcID 
INNER JOIN 
	dbo.QualOfInfo qi 
ON 
	qi.QualInfoID = t1.QualInfoID
INNER JOIN 
	dbo.SamplingAreas spa 
ON 
	spa.SampAreaID = t1.SampAreaID
INNER JOIN 
	dbo.CatchCodes fz 
ON 
	fz.CatchCodeID = t1.CatchCodeID
