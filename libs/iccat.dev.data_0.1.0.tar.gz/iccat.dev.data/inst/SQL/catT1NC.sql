-- T1NC CATALOGUE
SELECT
  t1.DS,
  t1.Species,
  t1.YearC,
  t1.StatusCPC,
  t1.FlagName,
  t1.Stock,
  t1.Stock AS Stock2,
  t1.GearGrp,
  SUM(t1.Qty) AS Qty,
  'w(t)' AS QtyUnit,
  'yy' AS TimeStrata,
  'ICCAT' AS GeoStrata,
  '...' AS ClassInterval,
  '...' AS FreqTypeCode
FROM (
		SELECT
			'1-t1' AS DS,
			sp.Alfa3FAO AS Species,
			t1.Year4 AS YearC,
			pt.StatusTypeID AS StatusCPC,
			fg.FlagName,
			sta.SAreaName AS Stock,
			gg.GearGrpCode AS GearGrp,
			t1.CatchMT AS Qty
		FROM
		  T1.dbo.T1CatchCur t1
		INNER JOIN
		  T1.dbo.InProcesses pr
		ON
		  pr.InProcID = t1.InProcID
		INNER JOIN
		  T1.dbo.Species sp
		ON
		  sp.SpeciesID = t1.SpeciesID
		INNER JOIN
		  T1.dbo.StocksAreas sta
		ON
		   sp.StockBoundID = sta.StockBoundID
		INNER JOIN
		  T1.dbo.StatAreas sa
		ON
		  sa.AreaID = t1.AreaID
		INNER JOIN
		  T1.dbo.StocksStAreasDetails sad
		ON
		  sad.AreaID = sa.AreaID AND
		  sad.StockAreaID = sta.StockAreaID
		INNER JOIN
		  T1.dbo.GearGrpBySpecies ggs
		ON
		  ggs.SpeciesID = sp.SpeciesID
		INNER JOIN
		  T1.dbo.GearGroups AS gg
		INNER JOIN
		  T1.dbo.Gears AS gr
		ON
		  gg.GearGroupID = gr.GearGroupID
		ON
		  ggs.GearGroupID = gg.GearGroupID AND
		  t1.GearID = gr.GearID
		INNER JOIN
		  T1.dbo.Fleets AS ft
		ON
		  t1.FleetID = ft.FleetID
		INNER JOIN
		  T1.dbo.Flags AS fg
		ON
		  ft.RepFlagID = fg.FlagID
		INNER JOIN
		  T1.dbo.Parties AS pt
		ON
		  pt.PartyID = fg.PartyID
		INNER JOIN
		  T1.dbo.CatchTypes dt
		ON
		  dt.CatchTypeID = t1.CatchTypeID
		WHERE
		  t1.CatchTypeID <> 22 AND
		  t1.CatchMT > 0
	) AS t1
WHERE
  @SpeciesFilter AND
  @StocksFilter AND
  @YearFilter
GROUP BY
  t1.DS,
  t1.Species,
  t1.YearC,
  t1.StatusCPC,
  t1.FlagName,
  t1.Stock,
  t1.GearGrp
