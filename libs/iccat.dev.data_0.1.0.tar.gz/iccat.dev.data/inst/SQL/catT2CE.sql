-- T2CE CATALOGUE
SELECT
	ce.DS,
	ce.Species,
	ce.YearC,
	ce.StatusCPC,
	ce.FlagName,
	ce.Stock,
	ce.Stock2,
	ce.GearGrp,
	SUM(ce.Qty) AS Qty,
	ce.QtyUnit,
	ce.TimeStrata,
	ce.GeoStrata,
	'...' AS ClassInterval,
	'...' AS FreqTypeCode
FROM (
	SELECT
		'2-ce' AS DS,
		sp.SpeciesCode AS Species,
		ceP.YearC,
		pt.StatusTypeID AS StatusCPC,
		fg.FlagName,
		dbSTAT.dbo.fn_getSpeciesStockFromLatLon(sp.SpeciesCode, QuadID, Lat, Lon) AS Stock2,
		CASE
			-- ALB, BFT, YFT, BET, SKJ, SWO, BUM, WHM, SAI, SPF + BSK, POR, SMA (and small tuna already)
			WHEN --ALB
				((sp.SpeciesCode = 'ALB') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN
				((sp.SpeciesCode = 'ALB') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0))
			THEN 'ATN'
			WHEN
				((sp.SpeciesCode = 'ALB') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 2) AND (Lat >= 0)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 3)) OR
				((sp.SpeciesCode = 'ALB') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATS'
			WHEN -- BFT
				((sp.SpeciesCode = 'BFT') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN
				((sp.SpeciesCode = 'BFT') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 15))  OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat >= 10) AND (Lon < 45)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat between 5 and 9) AND (Lon < 35)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon < 30)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 3) AND (Lon < 25)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 2))
			THEN 'ATE'
			WHEN
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat >= 10) AND (Lon >= 45)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat between 5 and 9) AND (Lon >= 35)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 30)) OR
				((sp.SpeciesCode = 'BFT') AND (QuadID = 3) AND (Lon >= 25))
			THEN 'ATW'
			--WHEN --YFT
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			--THEN 'MED'
			--WHEN
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 1) AND (Lat >= 50)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 1) AND (Lat between 0 and 9) AND (Lon between 0 and 14)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 2) AND (Lat >= 0)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 3) AND (Lon < 20)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 4) AND (Lon < 30))
			--THEN 'ATE'
			--WHEN
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 3) AND (Lon >= 20)) OR
			--	((sp.SpeciesCode = 'YFT') AND (QuadID = 4) AND (Lon >= 30))
			--THEN 'ATW'
			WHEN --YFT (since 2024-04-08)
				(sp.SpeciesCode IN ('YFT'))
			THEN 'A+M'
			WHEN -- SKJ
				((sp.SpeciesCode = 'SKJ') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'SKJ') AND (QuadID = 1) AND (Lat between 0 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'SKJ') AND (QuadID = 2) AND (Lat >= 0)) OR
				((sp.SpeciesCode = 'SKJ') AND (QuadID in (3,4)) AND (Lon < 30))
			THEN 'ATE'
			WHEN
				((sp.SpeciesCode = 'SKJ') AND(QuadID = 3) AND (Lon >= 30)) OR
				((sp.SpeciesCode = 'SKJ') AND(QuadID = 4) AND (Lon >= 30))
			THEN 'ATW'
			WHEN
				((sp.SpeciesCode = 'SKJ') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'SKJ') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN --BET
				(sp.SpeciesCode IN ('BET'))
			THEN 'A+M'
			WHEN --SWO
				((sp.SpeciesCode = 'SWO') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0))
			THEN 'ATN'
			WHEN
				((sp.SpeciesCode = 'SWO') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 2) AND (Lat >= 0)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 3)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATS'
			WHEN
				((sp.SpeciesCode = 'SWO') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'SWO') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN --BUM
				(sp.SpeciesCode = 'BUM')
			THEN 'A+M'
			WHEN --WHM
				(sp.SpeciesCode = 'WHM')
			THEN 'A+M'
			WHEN --SAI
				((sp.SpeciesCode = 'SAI') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 15)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 2)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 3) AND (Lon < 20)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon < 30)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 4) AND (Lat >= 5) AND (Lon < 40))
			THEN 'ATE'
			WHEN
				((sp.SpeciesCode = 'SAI') AND (QuadID = 4) AND (Lat >= 5) AND (Lon >= 40)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 30)) OR
				((sp.SpeciesCode = 'SAI') AND (QuadID = 3) AND (Lon >= 20))
			THEN 'ATW'
			WHEN--SPF
				((sp.SpeciesCode = 'SPF') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 15)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 2)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 3) AND (Lon < 20)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon < 30)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 4) AND (Lat >= 5) AND (Lon < 40))
			THEN 'ATE'
			WHEN
				((sp.SpeciesCode = 'SPF') AND (QuadID = 4) AND (Lat >= 5) AND (Lon >= 40)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 30)) OR
				((sp.SpeciesCode = 'SPF') AND (QuadID = 3) AND (Lon >= 20))
			THEN 'ATW'
			--sharks
			WHEN --BSH
				((sp.SpeciesCode = 'BSH') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0))
			THEN 'ATN'
			WHEN
				((sp.SpeciesCode = 'BSH') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 2) AND (Lat >= 0)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 3)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATS'
			WHEN
				((sp.SpeciesCode = 'BSH') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'BSH') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN --POR (since 2020-06-03 with 4 stocks)
				((sp.SpeciesCode = 'POR') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon between 0 and 40)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 40)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat >= 40) AND (Lon between 0 and 40))
			THEN 'ANE'
			WHEN
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0))
			THEN 'ANW'
			WHEN
				((sp.SpeciesCode = 'POR') AND (QuadID = 1) AND (Lat between 0 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 2) AND (Lat >= 0) AND (Lon < 20)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 3) AND (Lat >= 0) AND (Lon < 20)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon < 30))
			THEN 'ASE'
			WHEN
				((sp.SpeciesCode = 'POR') AND (QuadID = 3) AND (Lat >= 0) AND (Lon >= 20)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 30))
			THEN 'ASW'
			WHEN
				-- MED in cluded in ANE
				((sp.SpeciesCode = 'POR') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'POR') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN -- SMA
				((sp.SpeciesCode = 'SMA') AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0))
			THEN 'ATN'
			WHEN
				((sp.SpeciesCode = 'SMA') AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 2) AND (Lat >= 0)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 3)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATS'
			WHEN
				((sp.SpeciesCode = 'SMA') AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode = 'SMA') AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'


			-- all smal tunas (13 species: BON, LTA, FRI, BOP, BLF, 	SSM, KGM, BRS, BLT, WAH, MAW, COM, CER)
			WHEN -- BON, LTA, BOP, FRI: (ATL + MED)
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN -- BON LTA BOP FRI: (ATL + MED)
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 1) AND (Lat between 30 and 49) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon between 0 and 4))
			THEN 'MED'
			WHEN
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID IN (2,3))) OR
				((sp.SpeciesCode IN ('BON','LTA','FRI','BOP','BLF')) AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATL'
			WHEN
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 1) AND (Lat >= 50)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 1) AND (Lat between 5 and 9) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 4) AND (Lat between 5 and 34) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 4) AND (Lat between 35 and 39) AND (Lon >= 5)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 4) AND (Lat >= 40) AND (Lon >= 0)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 1) AND (Lat between 0 and 14) AND (Lon between 0 and 14)) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID IN (2,3))) OR
				((sp.SpeciesCode IN ('SSM','KGM','BRS','BLT','WAH','MAW','COM','CER')) AND (QuadID = 4) AND (Lat between 0 and 4) AND (Lon >= 0))
			THEN 'ATL'
			WHEN -- other SMT
				(sp.SpeciesCode IN ('SLT', 'KGX', 'DOL'))
			THEN 'A+M'
			ELSE '---'
		END AS Stock,
		gg.GearGrpCode AS GearGrp, ct.CatchTypeCode AS DataType,
		ceC.CatchStdCE AS Qty,
		CASE
			WHEN un.NorW = 'n' THEN 'num'
			WHEN un.NorW = 'w' THEN 'w(t)'
			ELSE '--'
		END AS QtyUnit,
		ts.TimePeriodGroup AS TimeStrata, gs.SquareTypeCode AS GeoStrata
	FROM
		dbSTAT.dbo.t2ceCatches ceC
	INNER JOIN
		dbSTAT.dbo.Species sp
	ON
		ceC.SpeciesID = sp.SpeciesID
	INNER JOIN
		dbSTAT.dbo.t2ceStrata ceS
	ON
		ceC.StrataID = ceS.StrataID
	INNER JOIN
		dbSTAT.dbo.t2ceProcesses ceP
	ON
		ceS.InProcID = ceP.InProcID
	INNER JOIN
		dbSTAT.dbo.Gears gr
	ON
		ceP.GearID = gr.GearID
	INNER JOIN
		dbSTAT.dbo.Fleets ft
	ON
		ceP.FleetID = ft.FleetID
	INNER JOIN
		dbSTAT.dbo.Flags fg
	ON
		ft.RepFlagID = fg.FlagID
	INNER JOIN
		dbSTAT.dbo.Parties pt
	ON
		pt.PartyID = fg.PartyID
	INNER JOIN
		dbSTAT.dbo.GearGroups gg
	ON
		gr.GearGrpID = gg.GearGrpID
	INNER JOIN
		dbSTAT.dbo.CatchTypes ct
	ON
		ct.CatchTypeID = ceC.CatchTypeID
	INNER JOIN
		dbSTAT.dbo.SquareTypes gs
	ON
		gs.SquareTypeID = ceS.SquareTypeID
	INNER JOIN
		dbSTAT.dbo.ProductTypes un
	ON
		un.ProductTypeID = ceC.ProductTypeID
	INNER JOIN
		dbSTAT.dbo.TimePeriods ts
	ON
		ts.TimePeriodID = ceS.TimePeriodID
	WHERE
		sp.SpeciesCode IN (
			'ALB', 'BFT', 'YFT', 'BET', 'SKJ', 'SWO', 'BUM', 'WHM', 'SAI', 'SPF',
			'BSH', 'POR', 'SMA',
			'BON','LTA','BOP', 'FRI', 'BLF', 'BLT', 'BRS', 'CER', 'DOL', 'KGM', 'KGX', 'MAW', 'SLT', 'SSM', 'WAH', 'COM'
		)
		AND ts.TimePeriodGroup IN ('mm') AND gs.SquareTypeCode IN ('1x1', '5x5', '5x10', '10x10', 'LatLon')
) AS ce
WHERE
	@SpeciesFilter AND
  @StocksFilter AND
  @YearFilter
GROUP BY
	ce.DS,
	ce.Species,
	ce.YearC,
	ce.StatusCPC,
	ce.FlagName,
	ce.Stock,
	ce.Stock2,
	ce.GearGrp,
	ce.QtyUnit,
	ce.TimeStrata,
	ce.GeoStrata
