SELECT
	szP.InProcID as DSetID, 
	pt.StatusTypeID, 
	fg.FlagName, 
	ft.FleetCode, 
	szP.YearC, 
	( szP.YearC / 10 ) * 10 as Decade, 
	sp.SpeciesCode, 
	sp.SpeciesGrp, 
	gg.GearGrpCode, 
	gr.GearCode,
	szP.SizeInfoID, 
	sloc.SampLocationCode,
	MAX(CASE szP.SizeInfoID WHEN 1 THEN 'cas' ELSE 'siz' END) as SizeInfoCode,	
	MAX(CASE WHEN szP.GearID IN (33, 35, 37, 38, 39, 40, 80, 81, 82, 83, 84) THEN 'DD' ELSE 'L' END) as LroD,
	sch.SchoolTypeCode, 
	frq.FreqTypeCode, 
	szP.SzInterval, 
	sl.SzClassLimitCode, 
	flt.FileTypeCode, 
	tp.TimePeriodGroup as TimeStrata, 
	st.SquareTypeCode as GeoStrata, 
	szS.Stock, si.SexCode, 
	MIN(szF.SizeClass) as MinClass,
	MAX(szF.SizeClass) as MaxClass,
	SUM((szF.SizeClass + szP.SzInterval/2) * szF.Nr) / SUM(szF.Nr)	as MeanSize,
	COUNT(szF.Nr) as NrRecs, 
	SUM(szF.Nr) as NrFish
FROM 
	dbSTAT.dbo.t2szProcesses szP 
INNER JOIN 
	dbSTAT.dbo.t2szStrata szS 
ON 
	szS.InProcID = szP.InProcID 
LEFT JOIN 
	dbSTAT.dbo.t2szFreqs szF
ON
	szF.StrataID= szS.StrataID
INNER JOIN 
	dbSTAT.dbo.TimePeriods tp
ON
	szS.TimePeriodCatch = tp.TimePeriodID
INNER JOIN 
	dbSTAT.dbo.SquareTypes st
ON
	st.SquareTypeID = szS.SquareTypeID
INNER JOIN 
	dbSTAT.dbo.FileTypes flt
ON
	flt.FileTypeID = szP.FileTypeID
INNER JOIN 
	dbSTAT.dbo.Fleets ft
ON
	ft.FleetID = szP.FleetID
INNER JOIN 
	dbSTAT.dbo.Flags fg
ON
	fg.FlagID = ft.RepFlagID
INNER JOIN 
	Parties pt
ON
	pt.PartyID = fg.PartyID
INNER JOIN 
	Gears gr
ON
	gr.GearID = szP.GearID
INNER JOIN 
	GearGroups gg
ON
	gg.GearGrpID = gr.GearGrpID 
INNER JOIN 
	Species sp
ON
	sp.SpeciesID = szP.SpeciesID
INNER JOIN 
	FreqTypes frq
ON
	frq.FreqTypeID = szP.FreqTypeID
INNER JOIN 
	SchoolTypes sch
ON
	sch.SchoolTypeID = szS.SchoolTypeID
INNER JOIN 
	SizeClassLimits sl
ON
	sl.SzClassLimitID =szP.SzClassLimit
INNER JOIN 
	SexInfo si
ON
	si.SexID = szF.SexID
INNER JOIN 
	dbSTATpre.dbo.SampLocations sloc
ON
	sloc.SampLocationID = szP.SampLocationID
