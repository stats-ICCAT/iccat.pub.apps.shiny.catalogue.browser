SELECT
	sp.SpeciesCode, 
	cd.YearC, 
	FLOOR(cd.YearC / 10) * 10 as Decade, 
	p.PartyName, 
	fg.FlagName, 
	ft.FleetCode, 
	cd.Stock, 
	cd.GearG as GearGrp, 
	st.SchoolTypeCode as SchoolType,
	cd.byQuarter as Trimester, 
	sa.SampAreaCode, 
	cd.QuadID, 
	cd.Lat5, 
	cd.Lon5,
	ROUND(SUM(Catch_t), 5) as Catch_t
FROM 
	CATDIS cd
INNER JOIN 
	T1.dbo.Fleets ft 
ON 
	ft.FleetID = cd.FleetID collate Latin1_General_BIN
INNER JOIN 
	T1.dbo.Flags fg 
ON 
	fg.FlagID = ft.RepFlagID
INNER JOIN 
	T1.dbo.Parties p 
ON 
	p.PartyID = fg.PartyID
INNER JOIN 
	Species sp 
ON 
	sp.SpeciesID = cd.SpeciesID
INNER JOIN 
	SchoolTypes st 
ON 
	st.SchoolTypeID = cd.SchoolTypeID
INNER JOIN 
	dbSTAT.dbo.SamplingAreas sa 
ON 
	sa.SampAreaID = dbo.fn_getSampAreaID(sp.SpeciesID, 6, cd.QuadID, cd.Lat5, cd.Lon5)
WHERE 
	sp.SpeciesCode IN (@SpeciesCode) AND
	cd.YearC BETWEEN @YearMin AND @YearMax
GROUP BY
	cd.RecID,
	sp.SpeciesCode, 
	cd.YearC, 
	FLOOR(cd.YearC / 10) * 10, 
	p.PartyName, 
	fg.FlagName, 
	ft.FleetCode, 
	cd.Stock, 
	cd.GearG, 
	st.SchoolTypeCode,
	cd.byQuarter, 
	sa.SampAreaCode, 
	cd.QuadID, 
	cd.Lat5, 
	cd.Lon5
ORDER BY
	sp.SpeciesCode, 
	cd.YearC, 
	fg.FlagName, 
	ft.FleetCode, 
	cd.Stock, 
	cd.GearG, 
	st.SchoolTypeCode,
	cd.byQuarter, 
	cd.QuadID, 
	cd.Lat5, 
	cd.Lon5
;
