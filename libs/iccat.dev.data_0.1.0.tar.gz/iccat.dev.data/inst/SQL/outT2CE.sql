SELECT
	ceP.InProcID AS DSetID, 
	ceP.YearC, 
	FLOOR(ceP.YearC/10) * 10 AS Decade, 
	pt.StatusTypeID, 
	fg.FlagName, 
	ft.FleetCode, 
	gg.GearGrpCode, 
	gr.GearCode, 
	ceP.CovRatio,
	et.EffortTypeCode AS EffortUnit, 
	fm.SchoolTypeCode AS FishModeCode, 
	ct.CatchTypeCode, 
	ptt.ProductTypeCode, 
	ftt.FileTypeCode AS FileType,
	tp.TimePeriodGroup AS TimeStrata, 
	st.SquareType AS GeoStrata, 
	sp.SpeciesGrp, 
	sp.SpeciesCode, 
	dbo.fn_getSpeciesStockFromLatLon(sp.SpeciesCode, ceS.QuadID, ceS.Lat, ceS.Lon) AS Stock, 
	SUM(ceC.CatchStdCE) AS qty
FROM 
	t2ceProcesses ceP 
INNER JOIN 
	t2ceStrata ceS 
ON 
	ceS.InProcID = ceP.InProcID 
INNER JOIN 
	t2ceEfforts ceE 
ON 
	ceE.StrataID = ceS.StrataID
INNER JOIN 
	t2ceCatches ceC 
ON 
	ceC.StrataID = ceS.StrataID
INNER JOIN 
	SquareTypes st 
ON 
	st.SquareTypeID = ceS.SquareTypeID 
INNER JOIN 
	TimePeriods tp 
ON 
	tp.TimePeriodID = ceS.TimePeriodID
INNER JOIN 
	Gears gr 
ON 
	gr.GearID = ceP.GearID 
INNER JOIN 
	GearGroups gg 
ON 
	gg.GearGrpID = gr.GearGrpID 
INNER JOIN 
	Fleets ft 
ON 
	ft.FleetID = ceP.FleetID
INNER JOIN 
	Flags fg 
ON 
	fg.FlagID = ft.RepFlagID
INNER JOIN 
	Parties pt 
ON 
	pt.PartyID = fg.PartyID
INNER JOIN 
	Species sp 
ON 
	sp.SpeciesID = ceC.SpeciesID 
INNER JOIN 
	FileTypes ftt 
ON 
	ftt.FileTypeID = ceP.FileTypeID
INNER JOIN 
	CatchTypes ct 
ON 
	ct.CatchTypeID = ceC.CatchTypeID
INNER JOIN 
	ProductTypes ptt 
ON 
	ptt.ProductTypeID = ceC.ProductTypeID 
INNER JOIN 
	EffortTypes et 
ON 
	et.EffortTypeID = ceE.EffortTypeID
INNER JOIN 
	SchoolTypes fm 
ON 
	fm.SchoolTypeID = ceS.SchoolTypeID
