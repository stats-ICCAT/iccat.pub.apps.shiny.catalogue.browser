#' Default function to retrieve a connection to databases hosted on the ICCAT servers
#'
#' @param server The database server name / IP address. Defaults to \code{\link{SERVER_ICARO}}
#' @param database The database name
#' @param encoding The database encoding. Defaults to \code{CP1252}
#' @param encoding The charset to use. Defaults to \code{UTF-8}
#' @return A connection to \code{\link{database}} on \code{\link{server}} using the trusted credentials of the current user
#' @export
DB_connect = function(server = SERVER_ICARO, database, encoding = "CP1252", charset = "UTF-8") {
  log_debug(
    paste0("Connecting to ", database, "@", server)
  )

  return(
    odbc::dbConnect(
      odbc(),
      driver = "SQL Server",
      server = server,
      database = database,
      encoding = encoding,
      clientcharset = charset
    )
  )
}

#' Connects to \code{\link{DATABASE_T1}} on the default database server
#' @return A connection to \code{\link{DATABASE_T1}}
#' @export
DB_T1   = function() { return(DB_connect(database = DATABASE_T1)) }

#' Connects to \code{\link{DATABASE_DB_STAT}} on the default database server
#' @return A connection to \code{\link{DATABASE_DB_STAT}}
#' @export
DB_STAT = function() { return(DB_connect(database = DATABASE_DB_STAT)) }

#' Connects to \code{\link{DATABASE_CATDIS}} on the default database server
#' @return A connection to \code{\link{DATABASE_CATDIS}}
#' @export
DB_CATDIS = function() { return(DB_connect(database = DATABASE_CATDIS)) }

#' Connects to \code{\link{DATABASE_GIS}} on the default database server
#' @return A connection to \code{\link{DATABASE_GIS}}
#' @export
DB_GIS  = function() { return(DB_connect(database = DATABASE_GIS)) }

#' Executes a SQL statement on a specific database connection
#' @param connection The database connection
#' @param statement The SQL statement to execute
#' @return The result of executing the statement on the database
#' @export
query = function(connection, statement) {
  log_debug(
    paste0("Performing query ", statement, " on ", connection)
  )

  return(
    odbc::dbGetQuery(
      connection,
      statement
    )
  )
}

#' Return the results of executing a SQL statement as a \code{\link{data.table}}
#' @param connection The database connection
#' @param statement The SQL statement to execute
#' @return The statement execution results as a \code{\link{data.table}}
#' @export
tabular_query = function(connection, statement) {
  return(
    data.table::as.data.table(
      query(
        connection,
        statement
      )
    )
  )
}
