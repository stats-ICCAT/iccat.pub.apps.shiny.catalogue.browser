### DATABASE SERVERS

#' The default database server symbolic name
#' @export
SERVER_ICARO = "ICARO"

### DATABASES

#' The \code{T1} database name
#' @export
DATABASE_T1 = "T1"

#' The \code{DBStat} database name
#' @export
DATABASE_DB_STAT = "dbSTAT"


#' The \code{CATDIS} database name
#' @export
DATABASE_CATDIS = "stCATDIS"

#' The \code{GIS} database name
#' @export
DATABASE_GIS = "NewGIS"
